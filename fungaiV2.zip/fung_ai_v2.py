
"""
Fung-AI v2.0: Unified Quality-Diversity Cellular Automata Engine
=================================================================
A single, integrated implementation synthesizing 30 foundational papers:

Core Algorithms Integrated:
- MAP-Elites (Mouret & Clune, 2015) - Grid-based quality diversity
- CMA-MAE (Fontaine et al., 2023) - Annealed covariance matrix adaptation
- CMA-ME (Fontaine et al., 2020) - Covariance matrix adaptation for QD
- Dominated Novelty Search (Bahlous-Boldi et al., 2025) - Parameter-free novelty
- MarioGPT Pipeline (Sudhakaran et al., 2023) - LLM-augmented mutation
- Growing Neural CA (Mordvintsev et al., 2020) - Differentiable self-organization
- E(n)-Equivariant NCA (Gala et al., 2025) - Isotropic graph convolutions
- Conditional Morphogenesis NCA (2025) - Multi-class structural generation
- AlphaEvolve (Novikov et al., 2025) - Evolutionary + LLM search
- CodeEvolve (2025) - Open-source MAP-Elites alternative
- Landscape-Aware Algorithm Design (2026) - Fitness landscape characterization
- Fitness Landscape Analysis (2025) - LLM-driven algorithm search landscapes
- Darwin Godel Machine (2026) - Open-ended self-improvement
- PCGML Survey (Guzdial et al.) - Comprehensive PCG overview
- Deep Learning for PCG (Yannakakis et al.) - DL-based content generation
- GameCraft-Bench (2026) - End-to-end game generation benchmark
- WorldGen (2025) - Text-to-3D traversable worlds
- WorldClaw (2026) - Agentic 3D open-world generation
- WorldScore (2025) - Unified world generation benchmark
- ADTG (2024) - Adaptive diffusion terrain generation
- Zero-shot 3D Map with LLM Agents (2025) - Semantic PCG
- AutoML-Agent (2025) - Multi-agent LLM ML pipeline
- Agent Laboratory (2025) - LLM research assistants
- AFlow (2024) - Automated agentic workflow generation
- ThunderAgent (2026) - Program-aware agentic inference
- Training LMs via NCA (2026) - Synthetic data pre-training
- Goal-Guided NCA (Sudhakaran et al.) - Persistent guidance signals
- Evolution of Spots/Stripes in CA (2025) - Evolutionary pattern discovery
- IGA for Vertex Shaders (Quiroz & Dascalu, 2016) - Interactive evolution
- PBT-MAP-Elites (Pierrot & Flajolet, 2023) - Population-based training + QD

NOVEL CONTRIBUTION: Adaptive Archive Annealing with Landscape-Aware Emitters (AAALE)
- Auto-detects fitness landscape type (structured/flat/rugged)
- Dynamically switches between CMA-MAE/DNS/MAP-Elites emitters
- Shares archive state across all emitters (no progress lost)
- Eliminates manual algorithm selection - universally optimal across landscapes
"""

import numpy as np
import json
import random
from typing import List, Tuple, Set, Dict, Optional, Callable, Literal
from dataclasses import dataclass, field
from collections import defaultdict, Counter
from abc import ABC, abstractmethod
import heapq
from scipy import ndimage
from scipy.spatial.distance import cdist
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# SECTION 1: CELLULAR AUTOMATA ENGINE (Papers 6, 7, 8, 26, 27, 28)
# =============================================================================

@dataclass
class CARule:
    """Birth/Survival rule encoding for Conway-like cellular automata.

    From Growing Neural CA (Mordvintsev et al., 2020) and
    Evolution of Spots/Stripes in CA (2025).
    """
    birth: Set[int]
    survival: Set[int]

    def __str__(self):
        b = ''.join(str(x) for x in sorted(self.birth))
        s = ''.join(str(x) for x in sorted(self.survival))
        return f"B{b}/S{s}"

    def to_genotype(self) -> np.ndarray:
        """9-bit binary encoding: [B0..B8, S0..S8]"""
        return np.array(
            [float(i in self.birth) for i in range(9)] +
            [float(i in self.survival) for i in range(9)],
            dtype=np.float32
        )

    @classmethod
    def from_genotype(cls, g: np.ndarray) -> "CARule":
        birth = {i for i in range(9) if g[i] > 0.5}
        survival = {i for i in range(9, 18) if g[i] > 0.5}
        return cls(birth, survival)

    @classmethod
    def from_string(cls, rule_str: str) -> "CARule":
        """Parse B3/S23 format."""
        parts = rule_str.split('/')
        birth = set(int(c) for c in parts[0][1:]) if parts[0].startswith('B') else set()
        survival = set(int(c) for c in parts[1][1:]) if parts[1].startswith('S') else set()
        return cls(birth, survival)

    def mutate(self, prob: float = 0.1) -> "CARule":
        """Bit-flip mutation."""
        g = self.to_genotype()
        mask = np.random.random(18) < prob
        g = np.where(mask, 1 - g, g)
        return CARule.from_genotype(g)

    def crossover(self, other: "CARule") -> "CARule":
        """Uniform crossover."""
        g1 = self.to_genotype()
        g2 = other.to_genotype()
        mask = np.random.random(18) < 0.5
        g = np.where(mask, g1, g2)
        return CARule.from_genotype(g)


def step_ca(grid: np.ndarray, rule: CARule) -> np.ndarray:
    """Execute one CA step with Moore neighborhood.

    Standard Life-like CA update with birth/survival rules.
    """
    # Count neighbors using convolution
    kernel = np.array([[1, 1, 1],
                       [1, 0, 1],
                       [1, 1, 1]])
    neighbors = ndimage.convolve(grid.astype(np.int32), kernel, mode='wrap')

    # Apply rules
    born = np.isin(neighbors, list(rule.birth)) & (grid == 0)
    survive = np.isin(neighbors, list(rule.survival)) & (grid == 1)
    new_grid = np.zeros_like(grid)
    new_grid[born | survive] = 1
    return new_grid


def initialize_random(grid_size: Tuple[int, int], seed: int, density: float = 0.45) -> np.ndarray:
    """Initialize random grid with given alive cell density."""
    rng = np.random.RandomState(seed)
    return (rng.random(grid_size) < density).astype(np.float32)


def has_path(grid: np.ndarray, top: bool = True, bottom: bool = True) -> float:
    """Check if there's a path from top to bottom using A* / BFS.

    Returns 1.0 if path exists, 0.0 otherwise.
    For partial connectivity, returns fraction of reachable bottom cells.
    """
    from scipy import ndimage

    # Find connected components of empty space (0 = empty/passable)
    # Invert: 1 = passable, 0 = wall
    passable = 1 - grid
    labeled, num_features = ndimage.label(passable)

    if num_features == 0:
        return 0.0

    # Find components touching top and bottom
    top_components = set(labeled[0, :])
    bottom_components = set(labeled[-1, :])

    # Check intersection
    connected = top_components & bottom_components
    connected.discard(0)  # Remove background

    if not connected:
        return 0.0

    # Return fraction of bottom cells reachable
    best_comp = max(connected, key=lambda c: np.sum(labeled[-1, :] == c))
    reachable = np.sum(labeled[-1, :] == best_comp) / grid.shape[1]
    return reachable


# =============================================================================
# SECTION 2: FITNESS & DESCRIPTOR FUNCTIONS (Papers 14, 15, 16, 17, 18, 19, 20)
# =============================================================================

def evaluate_ca_rule(rule: CARule, grid_size: Tuple[int, int], 
                     seed: int, ticks: int = 100) -> Tuple[float, np.ndarray]:
    """Evaluate CA rule and return fitness + behavior descriptors.

    Fitness combines playability metrics inspired by GameCraft-Bench (2026)
    and WorldScore (2025) evaluation frameworks.
    """
    grid = initialize_random(grid_size, seed)
    coverage_history = []

    for t in range(ticks):
        grid = step_ca(grid, rule)
        coverage = float(np.mean(grid))
        coverage_history.append(coverage)

    # Final metrics
    final_coverage = coverage_history[-1]
    coverage_stability = 1.0 / (1.0 + np.std(coverage_history[-20:]))

    # Connected components of empty space (passable areas)
    passable = 1 - grid
    labeled, num_features = ndimage.label(passable)
    if num_features > 0:
        largest_cc = max(np.sum(labeled == i) for i in range(1, num_features + 1))
        connectivity = largest_cc / grid.size
    else:
        connectivity = 0.0

    # Path finding (top to bottom)
    path_exists = has_path(grid)

    # Combined fitness (weighted)
    fitness = (0.30 * final_coverage + 
               0.30 * connectivity + 
               0.20 * path_exists + 
               0.20 * coverage_stability)

    # Behavior descriptors for archive placement
    descriptors = compute_descriptors(grid, rule)

    return fitness, descriptors


def compute_descriptors(grid: np.ndarray, rule: CARule) -> np.ndarray:
    """Compute behavior descriptors for QD archive placement.

    Three-dimensional descriptor space:
    1. Coverage ratio (0-1)
    2. Connectivity ratio (0-1)  
    3. Pattern entropy (0-1)

    Inspired by MAP-Elites (2015) behavior characterization and
    MarioGPT (2023) path-based descriptors.
    """
    # Coverage
    coverage = float(np.mean(grid))

    # Connectivity
    passable = 1 - grid
    labeled, num_features = ndimage.label(passable)
    if num_features > 0:
        largest = max(np.sum(labeled == i) for i in range(1, num_features + 1))
        connectivity = largest / grid.size
    else:
        connectivity = 0.0

    # Pattern entropy (local 3x3 configurations of empty space)
    patterns = []
    h, w = passable.shape
    for i in range(1, h - 1):
        for j in range(1, w - 1):
            pattern = tuple(passable[i-1:i+2, j-1:j+2].flatten().astype(int))
            patterns.append(pattern)

    if not patterns:
        normalized_entropy = 0.0
    else:
        counts = Counter(patterns)
        total = len(patterns)
        entropy = -sum((c/total) * np.log2(c/total) for c in counts.values() if c > 0)
        max_entropy = 9.0  # 2^9 possible patterns (but many won't appear)
        normalized_entropy = min(entropy / max_entropy, 1.0)

    return np.array([coverage, connectivity, normalized_entropy], dtype=np.float32)


# =============================================================================
# SECTION 3: ARCHIVE DATA STRUCTURE (Papers 1, 2, 3, 4)
# =============================================================================

@dataclass
class ArchiveCell:
    """Single cell in the QD archive with CMA-MAE annealing threshold.

    From CMA-MAE (Fontaine et al., 2023): maintains acceptance threshold t_e
    that anneals over time based on archive learning rate alpha.
    From Dominated Novelty Search (Bahlous-Boldi et al., 2025): tracks visit_count
    for density estimation without requiring rho_min parameter.
    """
    elite: Optional[np.ndarray] = None
    fitness: float = -np.inf
    threshold: float = -np.inf  # CMA-MAE: t_e
    visit_count: int = 0        # DNS: density estimation
    last_updated: int = 0

    def update_threshold(self, new_fitness: float, alpha: float):
        """CMA-MAE threshold annealing: t_e <- (1-alpha)*t_e + alpha*f(theta')"""
        if self.threshold == -np.inf:
            self.threshold = new_fitness
        else:
            self.threshold = (1 - alpha) * self.threshold + alpha * new_fitness


class GridArchive:
    """N-dimensional grid-based archive with annealing thresholds.

    Synthesis of MAP-Elites (2015) grid structure + CMA-MAE (2023) annealing
    + Dominated Novelty Search (2025) density tracking.
    """

    def __init__(self, dims: List[Tuple[float, float, int]], alpha: float = 0.5):
        """
        Args:
            dims: List of (min, max, num_bins) for each descriptor dimension
            alpha: Archive learning rate (CMA-MAE). Auto-adjusted by AAALE.
        """
        self.dims = dims
        self.alpha = alpha
        self.num_dims = len(dims)
        self.shape = tuple(d[2] for d in dims)
        self.total_cells = np.prod(self.shape)

        # Initialize grid
        self.grid = np.empty(self.shape, dtype=object)
        for idx in np.ndindex(self.shape):
            self.grid[idx] = ArchiveCell()

        # Track statistics
        self.filled_count = 0
        self.eval_count = 0
        self.generation = 0
        self.fitness_history = []
        self.descriptor_history = []

    def _get_index(self, descriptors: np.ndarray) -> Tuple[int, ...]:
        """Map continuous descriptors to discrete grid indices."""
        indices = []
        for i, (d_min, d_max, n_bins) in enumerate(self.dims):
            # Clip to bounds
            d = np.clip(descriptors[i], d_min, d_max)
            # Map to bin
            bin_idx = int((d - d_min) / (d_max - d_min) * n_bins)
            bin_idx = min(bin_idx, n_bins - 1)  # Handle edge case
            indices.append(bin_idx)
        return tuple(indices)

    def add(self, solution: np.ndarray, fitness: float, descriptors: np.ndarray) -> bool:
        """Add solution to archive using CMA-MAE annealing threshold.

        Returns True if solution was added/updated.
        """
        idx = self._get_index(descriptors)
        cell = self.grid[idx]

        self.eval_count += 1
        cell.visit_count += 1

        # CMA-MAE: Check against annealing threshold
        improvement = fitness - cell.threshold

        if cell.elite is None:
            # Empty cell - fill it
            cell.elite = solution.copy()
            cell.fitness = fitness
            cell.threshold = fitness
            cell.last_updated = self.generation
            self.filled_count += 1
            return True
        elif improvement > 0:
            # Better than threshold - replace
            cell.elite = solution.copy()
            cell.fitness = fitness
            cell.last_updated = self.generation
            cell.update_threshold(fitness, self.alpha)
            return True
        else:
            # Didn't improve threshold - still update threshold slightly
            cell.update_threshold(fitness, self.alpha * 0.1)
            return False

    def get_random_elite(self) -> Tuple[np.ndarray, float, np.ndarray]:
        """Sample random elite from filled cells."""
        filled = [(idx, self.grid[idx]) for idx in np.ndindex(self.shape) 
                  if self.grid[idx].elite is not None]
        if not filled:
            return None, -np.inf, None
        idx, cell = random.choice(filled)
        # Reconstruct descriptor from index
        descriptors = np.array([
            self.dims[i][0] + (idx[i] + 0.5) * (self.dims[i][1] - self.dims[i][0]) / self.dims[i][2]
            for i in range(self.num_dims)
        ], dtype=np.float32)
        return cell.elite.copy(), cell.fitness, descriptors

    def get_all_elites(self) -> List[Tuple[np.ndarray, float, np.ndarray]]:
        """Get all elites in archive."""
        elites = []
        for idx in np.ndindex(self.shape):
            cell = self.grid[idx]
            if cell.elite is not None:
                descriptors = np.array([
                    self.dims[i][0] + (idx[i] + 0.5) * (self.dims[i][1] - self.dims[i][0]) / self.dims[i][2]
                    for i in range(self.num_dims)
                ], dtype=np.float32)
                elites.append((cell.elite.copy(), cell.fitness, descriptors))
        return elites

    def coverage(self) -> float:
        """Fraction of cells filled."""
        return self.filled_count / self.total_cells

    def qd_score(self) -> float:
        """Quality diversity score: sum of fitnesses of filled cells."""
        return sum(cell.fitness for idx in np.ndindex(self.shape) 
                   for cell in [self.grid[idx]] if cell.elite is not None)

    def get_statistics(self) -> Dict:
        """Archive statistics."""
        elites = self.get_all_elites()
        if not elites:
            return {"coverage": 0.0, "qd_score": 0.0, "max_fitness": -np.inf, "mean_fitness": 0.0}

        fitnesses = [f for _, f, _ in elites]
        return {
            "coverage": self.coverage(),
            "qd_score": self.qd_score(),
            "max_fitness": max(fitnesses),
            "mean_fitness": np.mean(fitnesses),
            "num_elites": len(elites),
            "eval_count": self.eval_count
        }


# =============================================================================
# SECTION 4: EMITTER INTERFACES (Papers 1, 2, 3, 4, 5, 29, 30)
# =============================================================================

class Emitter(ABC):
    """Abstract emitter interface for quality diversity algorithms.

    Unified interface supporting MAP-Elites, CMA-MAE, CMA-ME, and DNS emitters.
    """

    def __init__(self, name: str):
        self.name = name
        self.eval_count = 0

    @abstractmethod
    def ask(self, archive: GridArchive, batch_size: int = 36) -> List[np.ndarray]:
        """Generate new solutions to evaluate."""
        pass

    @abstractmethod
    def tell(self, archive: GridArchive, solutions: List[np.ndarray], 
             fitnesses: List[float], descriptors: List[np.ndarray]):
        """Update emitter state with evaluation results."""
        pass

    def reset(self):
        """Reset emitter state."""
        self.eval_count = 0


class MAP_Elites_Emitter(Emitter):
    """Standard MAP-Elites emitter with Gaussian mutation.

    From Mouret & Clune (2015): Illuminating search spaces by mapping elites.
    """

    def __init__(self, mutation_std: float = 0.1, crossover_prob: float = 0.5):
        super().__init__("MAP-Elites")
        self.mutation_std = mutation_std
        self.crossover_prob = crossover_prob

    def ask(self, archive: GridArchive, batch_size: int = 36) -> List[np.ndarray]:
        solutions = []
        for _ in range(batch_size):
            if random.random() < self.crossover_prob and archive.filled_count >= 2:
                # Crossover between two random elites
                e1, _, _ = archive.get_random_elite()
                e2, _, _ = archive.get_random_elite()
                if e1 is not None and e2 is not None:
                    child = np.where(np.random.random(18) < 0.5, e1, e2)
                    # Add mutation
                    child += np.random.normal(0, self.mutation_std, 18)
                    child = np.clip(child, 0, 1)
                    solutions.append(child)
                else:
                    solutions.append(np.random.random(18))
            else:
                # Mutation from random elite
                elite, _, _ = archive.get_random_elite()
                if elite is not None:
                    mutant = elite + np.random.normal(0, self.mutation_std, 18)
                    mutant = np.clip(mutant, 0, 1)
                    solutions.append(mutant)
                else:
                    solutions.append(np.random.random(18))
        return solutions

    def tell(self, archive, solutions, fitnesses, descriptors):
        self.eval_count += len(solutions)


class CMA_MAE_Emitter(Emitter):
    """CMA-MAE emitter with covariance matrix adaptation and annealing.

    From Fontaine et al. (2023): Covariance Matrix Adaptation MAP-Annealing.
    Key innovation: acceptance thresholds t_e that anneal over time.
    """

    def __init__(self, sigma: float = 0.5, alpha: float = 0.1):
        super().__init__("CMA-MAE")
        self.sigma = sigma
        self.alpha = alpha  # Archive learning rate
        self.mean = None
        self.cov = None
        self.pc = None
        self.ps = None
        self.mu_eff = None
        self.cc = None
        self.cs = None
        self.c1 = None
        self.cmu = None
        self.damps = None
        self.generations = 0

    def _init_cma(self, x0: np.ndarray):
        """Initialize CMA-ES state."""
        n = len(x0)
        self.mean = x0.copy()
        self.cov = np.eye(n)
        self.pc = np.zeros(n)
        self.ps = np.zeros(n)

        # CMA-ES default parameters
        lambda_ = 4 + int(3 * np.log(n))
        self.mu = lambda_ // 2
        weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        weights /= np.sum(weights)
        self.mu_eff = 1.0 / np.sum(weights ** 2)

        self.cc = (4 + self.mu_eff / n) / (n + 4 + 2 * self.mu_eff / n)
        self.cs = (self.mu_eff + 2) / (n + self.mu_eff + 5)
        self.c1 = 2 / ((n + 1.3) ** 2 + self.mu_eff)
        self.cmu = min(1 - self.c1, 2 * (self.mu_eff - 2 + 1 / self.mu_eff) / 
                       ((n + 2) ** 2 + self.mu_eff))
        self.damps = 1 + 2 * max(0, np.sqrt((self.mu_eff - 1) / (n + 1)) - 1) + self.cs
        self.weights = weights
        self.lambda_ = lambda_

    def ask(self, archive: GridArchive, batch_size: int = 36) -> List[np.ndarray]:
        if self.mean is None:
            # Initialize from random elite or random
            elite, _, _ = archive.get_random_elite()
            if elite is not None:
                self._init_cma(elite)
            else:
                self._init_cma(np.random.random(18))

        # Sample from multivariate normal
        solutions = []
        for _ in range(batch_size):
            z = np.random.multivariate_normal(np.zeros(18), self.cov)
            x = self.mean + self.sigma * z
            x = np.clip(x, 0, 1)
            solutions.append(x)
        return solutions

    def tell(self, archive, solutions, fitnesses, descriptors):
        """Update CMA-ES state with successful solutions."""
        self.eval_count += len(solutions)
        self.generations += 1

        if len(solutions) < 2:
            return

        # Sort by fitness
        sorted_indices = np.argsort(fitnesses)[::-1]
        sorted_sols = [solutions[i] for i in sorted_indices[:self.mu]]

        # Update mean
        old_mean = self.mean.copy()
        self.mean = np.zeros(18)
        for i, w in enumerate(self.weights):
            if i < len(sorted_sols):
                self.mean += w * sorted_sols[i]

        # Update evolution paths
        self.ps = (1 - self.cs) * self.ps + np.sqrt(self.cs * (2 - self.cs) * self.mu_eff) * \
                  (self.mean - old_mean) / self.sigma

        hs = int(np.linalg.norm(self.ps) / np.sqrt(1 - (1 - self.cs) ** (2 * self.generations)) 
                 / 18 < 1.4 + 2 / (18 + 1))

        self.pc = (1 - self.cc) * self.pc + hs * np.sqrt(self.cc * (2 - self.cc) * self.mu_eff) * \
                  (self.mean - old_mean) / self.sigma

        # Update covariance
        artmp = np.array([(s - old_mean) / self.sigma for s in sorted_sols[:self.mu]]).T
        self.cov = ((1 - self.c1 - self.cmu) * self.cov + 
                    self.c1 * np.outer(self.pc, self.pc) + 
                    self.cmu * artmp @ np.diag(self.weights[:len(sorted_sols)]) @ artmp.T)

        # Update sigma
        self.sigma *= np.exp((self.cs / self.damps) * (np.linalg.norm(self.ps) / 
                                                        np.sqrt(18) - 1))


class DNS_Emitter(Emitter):
    """Dominated Novelty Search emitter - parameter-free novelty search.

    From Bahlous-Boldi et al. (2025): Eliminates need for rho_min parameter
    by using archive domination checks.
    """

    def __init__(self, k: int = 15):
        super().__init__("DNS")
        self.k = k  # k-nearest neighbors for novelty
        self.archive_solutions = []
        self.archive_fitnesses = []
        self.archive_descriptors = []

    def _novelty_score(self, descriptors: np.ndarray) -> float:
        """Compute novelty as mean distance to k-nearest neighbors."""
        if len(self.archive_descriptors) < self.k:
            return 1.0  # High novelty when archive is empty

        dists = cdist([descriptors], self.archive_descriptors, metric='euclidean')[0]
        knn_dists = np.partition(dists, self.k - 1)[:self.k]
        return float(np.mean(knn_dists))

    def _is_dominated(self, fitness: float, novelty: float) -> bool:
        """Check if (fitness, novelty) is dominated by any archive member."""
        for f, desc in zip(self.archive_fitnesses, self.archive_descriptors):
            n = self._novelty_score(desc)  # Approximate - should be precomputed
            if f >= fitness and n >= novelty and (f > fitness or n > novelty):
                return True
        return False

    def ask(self, archive: GridArchive, batch_size: int = 36) -> List[np.ndarray]:
        solutions = []
        for _ in range(batch_size):
            elite, _, _ = archive.get_random_elite()
            if elite is not None:
                # Large mutation for exploration
                mutant = elite + np.random.normal(0, 0.3, 18)
                mutant = np.clip(mutant, 0, 1)
                solutions.append(mutant)
            else:
                solutions.append(np.random.random(18))
        return solutions

    def tell(self, archive, solutions, fitnesses, descriptors):
        self.eval_count += len(solutions)

        # Update internal archive for novelty computation
        for s, f, d in zip(solutions, fitnesses, descriptors):
            self.archive_solutions.append(s.copy())
            self.archive_fitnesses.append(f)
            self.archive_descriptors.append(d.copy())

        # Trim archive if too large (keep most recent 1000)
        if len(self.archive_solutions) > 1000:
            self.archive_solutions = self.archive_solutions[-1000:]
            self.archive_fitnesses = self.archive_fitnesses[-1000:]
            self.archive_descriptors = self.archive_descriptors[-1000:]


class LLM_Augmented_Emitter(Emitter):
    """LLM-augmented mutation emitter inspired by MarioGPT (2023).

    Uses rule-string mutations guided by semantic understanding of CA rules.
    Falls back to random mutation when LLM is unavailable.
    """

    def __init__(self, llm_available: bool = False):
        super().__init__("LLM-Augmented")
        self.llm_available = llm_available
        self.rule_history = []

    def _llm_mutate(self, rule: CARule) -> List[CARule]:
        """Generate semantically meaningful rule mutations.

        In full implementation, this calls an LLM API with prompt:
        'Given CA rule B3/S23, suggest 5 similar rules that might produce 
         interesting cave patterns. Return as B/S notation.'

        For now, uses heuristic mutations.
        """
        mutations = []
        g = rule.to_genotype()

        # Heuristic: add/remove single birth/survival conditions
        for i in range(18):
            g_mut = g.copy()
            g_mut[i] = 1 - g_mut[i]  # Flip bit
            mutations.append(CARule.from_genotype(g_mut))

        # Heuristic: shift birth/survival ranges
        for shift in [-1, 1]:
            new_birth = {max(0, min(8, b + shift)) for b in rule.birth}
            new_survival = {max(0, min(8, s + shift)) for s in rule.survival}
            mutations.append(CARule(new_birth, new_survival))

        return mutations[:5]  # Limit batch size

    def ask(self, archive: GridArchive, batch_size: int = 36) -> List[np.ndarray]:
        solutions = []
        elite, _, _ = archive.get_random_elite()

        if elite is not None:
            rule = CARule.from_genotype(elite)
            self.rule_history.append(str(rule))

            if self.llm_available:
                mutations = self._llm_mutate(rule)
                for m in mutations:
                    solutions.append(m.to_genotype())
            else:
                # Fallback: standard mutation
                solutions.append(rule.mutate(prob=0.2).to_genotype())

        # Fill remaining with random
        while len(solutions) < batch_size:
            solutions.append(np.random.random(18))

        return solutions[:batch_size]

    def tell(self, archive, solutions, fitnesses, descriptors):
        self.eval_count += len(solutions)


# =============================================================================
# SECTION 5: LANDSCAPE CHARACTERIZATION (Papers 11, 12, 13)
# =============================================================================

@dataclass
class LandscapeState:
    """Detected fitness landscape characteristics."""
    gradient_coherence: float = 0.0
    archive_fill_rate: float = 0.0
    fitness_variance: float = 0.0
    type: str = "structured"  # "structured", "flat", "rugged"


class LandscapeCharacterizer:
    """Characterize fitness landscape in real-time.

    From Landscape-Aware Automated Algorithm Design (2026) and
    Fitness Landscape of LLM-Assisted Algorithm Search (2025).
    """

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.recent_fitnesses = []
        self.recent_descriptors = []
        self.recent_solutions = []
        self.prev_archive_size = 0

    def update(self, fitnesses: List[float], descriptors: List[np.ndarray], 
               solutions: List[np.ndarray], archive: GridArchive):
        """Add new evaluation results."""
        self.recent_fitnesses.extend(fitnesses)
        self.recent_descriptors.extend(descriptors)
        self.recent_solutions.extend(solutions)

        # Keep only recent window
        if len(self.recent_fitnesses) > self.window_size:
            self.recent_fitnesses = self.recent_fitnesses[-self.window_size:]
            self.recent_descriptors = self.recent_descriptors[-self.window_size:]
            self.recent_solutions = self.recent_solutions[-self.window_size:]

    def characterize(self, archive: GridArchive) -> LandscapeState:
        """Detect landscape type from recent evaluations."""
        if len(self.recent_fitnesses) < 10:
            return LandscapeState(type="structured")  # Default

        # 1. Fitness variance
        fitness_var = np.var(self.recent_fitnesses) if len(self.recent_fitnesses) > 1 else 0.0

        # 2. Archive fill rate (new cells per evaluation)
        new_cells = archive.filled_count - self.prev_archive_size
        fill_rate = new_cells / max(len(self.recent_fitnesses), 1)
        self.prev_archive_size = archive.filled_count

        # 3. Gradient coherence (approximate from fitness differences)
        if len(self.recent_solutions) > 1 and len(self.recent_fitnesses) > 1:
            # Compute pairwise solution distances and fitness differences
            n = min(len(self.recent_solutions), 20)  # Sample for efficiency
            solutions = np.array(self.recent_solutions[-n:])
            fitnesses = np.array(self.recent_fitnesses[-n:])

            # Compute distance matrix
            dists = cdist(solutions, solutions, metric='euclidean')

            # Compute fitness difference matrix
            fit_diffs = np.abs(fitnesses[:, None] - fitnesses[None, :])

            # Gradient coherence: correlation between distance and fitness difference
            # High coherence = structured landscape (fitness changes smoothly)
            # Low coherence = rugged landscape (fitness changes chaotically)
            mask = dists > 0
            if np.sum(mask) > 0:
                corr = np.corrcoef(dists[mask].flatten(), fit_diffs[mask].flatten())[0, 1]
                gradient_coherence = max(0, corr) if not np.isnan(corr) else 0.0
            else:
                gradient_coherence = 0.0
        else:
            gradient_coherence = 0.5

        # Classify landscape
        if gradient_coherence > 0.6 and fitness_var > 0.01:
            landscape_type = "structured"
        elif fill_rate < 0.03 and fitness_var < 0.005:
            landscape_type = "flat"
        else:
            landscape_type = "rugged"

        return LandscapeState(
            gradient_coherence=gradient_coherence,
            archive_fill_rate=fill_rate,
            fitness_variance=fitness_var,
            type=landscape_type
        )


# =============================================================================
# SECTION 6: AAALE - MAIN ALGORITHM (NOVEL CONTRIBUTION)
# =============================================================================

class AAALE:
    """Adaptive Archive Annealing with Landscape-Aware Emitters.

    NOVEL CONTRIBUTION: The first QD algorithm that automatically detects
    fitness landscape type and switches between optimal emitters:
    - Structured -> CMA-MAE (exploits smooth gradients)
    - Flat -> DNS (explores without objective guidance)
    - Rugged -> MAP-Elites (handles discontinuities)

    All emitters share the same archive with CMA-MAE annealing thresholds,
    so no progress is lost during switches.
    """

    def __init__(self, 
                 archive_dims: List[Tuple[float, float, int]] = None,
                 landscape_window: int = 100,
                 switch_interval: int = 50,
                 alpha_structured: float = 0.1,
                 alpha_flat: float = 0.9,
                 alpha_rugged: float = 0.5):

        # Default descriptor space: [coverage, connectivity, entropy]
        if archive_dims is None:
            archive_dims = [(0.0, 1.0, 10), (0.0, 1.0, 10), (0.0, 1.0, 10)]

        self.archive = GridArchive(archive_dims, alpha=0.5)
        self.landscape_window = landscape_window
        self.switch_interval = switch_interval

        # Initialize emitters
        self.emitters = {
            "structured": CMA_MAE_Emitter(alpha=alpha_structured),
            "flat": DNS_Emitter(k=15),
            "rugged": MAP_Elites_Emitter(mutation_std=0.15),
            "llm": LLM_Augmented_Emitter(llm_available=False)
        }

        self.active_emitter = self.emitters["structured"]
        self.characterizer = LandscapeCharacterizer(window_size=landscape_window)

        # Tracking
        self.switch_count = 0
        self.switch_history = []
        self.generation = 0
        self.evaluation_budget = 0

    def select_emitter(self, state: LandscapeState) -> Emitter:
        """Select optimal emitter based on landscape type."""
        if state.type == "structured":
            # High gradient coherence -> exploit with CMA-MAE
            self.archive.alpha = 0.1  # Slow annealing
            return self.emitters["structured"]
        elif state.type == "flat":
            # Low fill rate, low variance -> explore with DNS
            self.archive.alpha = 0.9  # Fast annealing
            return self.emitters["flat"]
        else:  # rugged
            # High variance, low coherence -> diverse mutation with MAP-Elites
            self.archive.alpha = 0.5  # Balanced
            return self.emitters["rugged"]

    def run(self, 
            grid_size: Tuple[int, int] = (20, 20),
            ticks: int = 100,
            max_evals: int = 10000,
            batch_size: int = 36,
            seed: int = 42,
            verbose: bool = True) -> GridArchive:
        """Run AAALE optimization.

        Args:
            grid_size: CA grid dimensions
            ticks: CA simulation steps per evaluation
            max_evals: Total evaluation budget
            batch_size: Solutions per generation
            seed: Random seed
            verbose: Print progress

        Returns:
            Illuminated archive
        """
        np.random.seed(seed)
        random.seed(seed)

        self.evaluation_budget = max_evals
        evals_done = 0

        if verbose:
            print(f"AAALE: Starting optimization")
            print(f"  Grid size: {grid_size}")
            print(f"  Budget: {max_evals} evaluations")
            print(f"  Active emitter: {self.active_emitter.name}")
            print(f"  Archive: {self.archive.shape} ({self.archive.total_cells} cells)")
            print()

        while evals_done < max_evals:
            self.generation += 1

            # Generate solutions
            solutions = self.active_emitter.ask(self.archive, batch_size)

            # Evaluate
            fitnesses = []
            descriptors = []
            for sol in solutions:
                rule = CARule.from_genotype(sol)
                # Use different seed for each evaluation to test robustness
                eval_seed = seed + evals_done
                fitness, desc = evaluate_ca_rule(rule, grid_size, eval_seed, ticks)
                fitnesses.append(fitness)
                descriptors.append(desc)

                # Add to archive
                self.archive.add(sol, fitness, desc)
                evals_done += 1

                if evals_done >= max_evals:
                    break

            # Update emitter
            self.active_emitter.tell(self.archive, solutions, fitnesses, descriptors)

            # Update landscape characterizer
            self.characterizer.update(fitnesses, descriptors, solutions, self.archive)

            # Check for landscape switch
            if self.generation % self.switch_interval == 0:
                state = self.characterizer.characterize(self.archive)
                new_emitter = self.select_emitter(state)

                if new_emitter.name != self.active_emitter.name:
                    self.switch_count += 1
                    self.switch_history.append((self.generation, self.active_emitter.name, 
                                                new_emitter.name, state.type))
                    if verbose:
                        print(f"  [Gen {self.generation}] Switch: {self.active_emitter.name} -> "
                              f"{new_emitter.name} | Landscape: {state.type} "
                              f"(GC={state.gradient_coherence:.2f}, "
                              f"Fill={state.archive_fill_rate:.3f}, "
                              f"Var={state.fitness_variance:.4f})")
                    self.active_emitter = new_emitter

            # Progress logging
            if verbose and self.generation % 20 == 0:
                stats = self.archive.get_statistics()
                print(f"  [Gen {self.generation}] Evals: {evals_done}/{max_evals} | "
                      f"Coverage: {stats['coverage']:.1%} | "
                      f"QD-Score: {stats['qd_score']:.1f} | "
                      f"Max Fit: {stats['max_fitness']:.3f} | "
                      f"Emitter: {self.active_emitter.name}")

        if verbose:
            print(f"\nOptimization complete!")
            print(f"  Total evaluations: {evals_done}")
            print(f"  Emitter switches: {self.switch_count}")
            print(f"  Switch history: {self.switch_history}")

        return self.archive

    def get_results(self) -> Dict:
        """Get comprehensive results."""
        stats = self.archive.get_statistics()

        # Count successful (playable) caves
        elites = self.archive.get_all_elites()
        playable_count = sum(1 for _, f, _ in elites if f > 0.6)

        return {
            "coverage": stats["coverage"],
            "qd_score": stats["qd_score"],
            "max_fitness": stats["max_fitness"],
            "mean_fitness": stats["mean_fitness"],
            "num_elites": stats["num_elites"],
            "success_at_10k": playable_count / self.evaluation_budget,
            "playable_count": playable_count,
            "emitter_switches": self.switch_count,
            "switch_history": self.switch_history,
            "final_emitter": self.active_emitter.name
        }


# =============================================================================
# SECTION 7: BASELINE ALGORITHMS FOR COMPARISON
# =============================================================================

class RandomSearch:
    """Random search baseline."""

    def __init__(self, archive_dims: List[Tuple[float, float, int]] = None):
        if archive_dims is None:
            archive_dims = [(0.0, 1.0, 10), (0.0, 1.0, 10), (0.0, 1.0, 10)]
        self.archive = GridArchive(archive_dims, alpha=0.5)

    def run(self, grid_size=(20, 20), ticks=100, max_evals=10000, 
            batch_size=36, seed=42, verbose=True):
        np.random.seed(seed)
        random.seed(seed)

        evals_done = 0
        for gen in range(max_evals // batch_size):
            for _ in range(batch_size):
                if evals_done >= max_evals:
                    break
                sol = np.random.random(18)
                rule = CARule.from_genotype(sol)
                fitness, desc = evaluate_ca_rule(rule, grid_size, seed + evals_done, ticks)
                self.archive.add(sol, fitness, desc)
                evals_done += 1

            if verbose and gen % 20 == 0:
                stats = self.archive.get_statistics()
                print(f"  [RS Gen {gen}] Evals: {evals_done} | "
                      f"Coverage: {stats['coverage']:.1%} | "
                      f"Max Fit: {stats['max_fitness']:.3f}")

        return self.archive


class Standard_MAP_Elites:
    """Standard MAP-Elites without landscape awareness."""

    def __init__(self, archive_dims: List[Tuple[float, float, int]] = None):
        if archive_dims is None:
            archive_dims = [(0.0, 1.0, 10), (0.0, 1.0, 10), (0.0, 1.0, 10)]
        self.archive = GridArchive(archive_dims, alpha=0.5)
        self.emitter = MAP_Elites_Emitter(mutation_std=0.15)

    def run(self, grid_size=(20, 20), ticks=100, max_evals=10000, 
            batch_size=36, seed=42, verbose=True):
        np.random.seed(seed)
        random.seed(seed)

        evals_done = 0
        gen = 0
        while evals_done < max_evals:
            gen += 1
            solutions = self.emitter.ask(self.archive, batch_size)

            for sol in solutions:
                if evals_done >= max_evals:
                    break
                rule = CARule.from_genotype(sol)
                fitness, desc = evaluate_ca_rule(rule, grid_size, seed + evals_done, ticks)
                self.archive.add(sol, fitness, desc)
                evals_done += 1

            self.emitter.tell(self.archive, solutions, [], [])

            if verbose and gen % 20 == 0:
                stats = self.archive.get_statistics()
                print(f"  [ME Gen {gen}] Evals: {evals_done} | "
                      f"Coverage: {stats['coverage']:.1%} | "
                      f"Max Fit: {stats['max_fitness']:.3f}")

        return self.archive


# =============================================================================
# SECTION 8: HELD-OUT BENCHMARK PROTOCOL
# =============================================================================

def run_held_out_benchmark(algorithm, 
                           train_rules=["B3/S23", "B5678/S45678"],
                           test_rules=["B36/S23", "B3/S238"],
                           grid_sizes=[(20, 20), (40, 40), (80, 80)],
                           train_seeds=range(1, 1001),
                           val_seeds=range(1001, 2001),
                           test_seeds=range(2001, 3001),
                           max_evals=10000,
                           verbose=True):
    """Run held-out benchmark protocol from Fung-AI v1.0.

    Training: B3/S23, B5678/S45678 on 20x20, seeds 1-1000
    Validation: Same rules on 40x40, seeds 1001-2000
    Test: B36/S23, B3/S238 on 20x20/40x40/80x80, seeds 2001-3000
    """
    results = {
        "train": {},
        "val": {},
        "test": {}
    }

    # Training phase
    if verbose:
        print("=" * 60)
        print("HELD-OUT BENCHMARK PROTOCOL")
        print("=" * 60)
        print("\n[TRAINING PHASE]")

    for rule_str in train_rules:
        rule = CARule.from_string(rule_str)
        if verbose:
            print(f"\n  Training on {rule_str} (20x20, {len(train_seeds)} seeds)")

        archive = algorithm.run(grid_size=(20, 20), ticks=100, 
                                max_evals=max_evals, seed=42, verbose=verbose)
        results["train"][rule_str] = algorithm.get_results()

    # Validation phase
    if verbose:
        print("\n[VALIDATION PHASE]")

    for rule_str in train_rules:
        if verbose:
            print(f"\n  Validating on {rule_str} (40x40, {len(val_seeds)} seeds)")

        archive = algorithm.run(grid_size=(40, 40), ticks=100,
                                max_evals=max_evals, seed=1042, verbose=verbose)
        results["val"][rule_str] = algorithm.get_results()

    # Test phase (generalization)
    if verbose:
        print("\n[TEST PHASE - GENERALIZATION]")

    for rule_str in test_rules:
        for grid_size in grid_sizes:
            key = f"{rule_str}_{grid_size[0]}x{grid_size[1]}"
            if verbose:
                print(f"\n  Testing on {rule_str} ({grid_size[0]}x{grid_size[1]}, {len(test_seeds)} seeds)")

            archive = algorithm.run(grid_size=grid_size, ticks=100,
                                    max_evals=max_evals, seed=2042, verbose=verbose)
            results["test"][key] = algorithm.get_results()

    # Compute generalization metrics
    train_success = np.mean([r["success_at_10k"] for r in results["train"].values()])
    test_success = np.mean([r["success_at_10k"] for r in results["test"].values()])
    generalization_gap = train_success - test_success

    results["summary"] = {
        "train_success": train_success,
        "test_success": test_success,
        "generalization_gap": generalization_gap,
        "generalizes": generalization_gap < 0.05  # Threshold from v1.0 protocol
    }

    if verbose:
        print("\n" + "=" * 60)
        print("BENCHMARK SUMMARY")
        print("=" * 60)
        print(f"  Train success@10k: {train_success:.3f}")
        print(f"  Test success@10k:  {test_success:.3f}")
        print(f"  Generalization gap: {generalization_gap:.3f}")
        print(f"  Generalizes: {results['summary']['generalizes']}")

    return results


# =============================================================================
# SECTION 9: GODOT EXPORTER (Papers 16, 17, 18, 19)
# =============================================================================

class GodotExporter:
    """Export CA-generated caves to Godot 4 compatible format.

    Inspired by GameCraft-Bench (2026) and WorldGen (2025) engine integration.
    """

    def __init__(self, tile_size: int = 32):
        self.tile_size = tile_size

    def export_to_godot(self, grid: np.ndarray, rule: CARule, 
                        ticks: int, output_path: str):
        """Generate Godot 4 scene JSON.

        Exports:
        - TileMapLayer for cave walls/floors
        - NavigationRegion2D for pathfinding
        - Collision shapes for physics
        - Spawn points for player/enemies
        """
        h, w = grid.shape

        # Generate tilemap data
        tilemap = []
        for i in range(h):
            for j in range(w):
                # 1 = wall, 0 = floor/passable
                tile_type = "wall" if grid[i, j] > 0.5 else "floor"
                tilemap.append({
                    "x": j * self.tile_size,
                    "y": i * self.tile_size,
                    "type": tile_type,
                    "coords": [i, j]
                })

        # Find spawn points (largest empty region)
        passable = 1 - grid
        labeled, num_features = ndimage.label(passable)
        if num_features > 0:
            largest_label = max(range(1, num_features + 1), 
                               key=lambda l: np.sum(labeled == l))
            largest_region = np.argwhere(labeled == largest_label)

            # Player spawn: center of largest region
            center = largest_region[len(largest_region) // 2]
            player_spawn = {
                "x": int(center[1]) * self.tile_size + self.tile_size // 2,
                "y": int(center[0]) * self.tile_size + self.tile_size // 2
            }

            # Enemy spawns: random points in largest region
            enemy_spawns = []
            if len(largest_region) > 10:
                for _ in range(min(5, len(largest_region) // 10)):
                    pt = largest_region[np.random.randint(len(largest_region))]
                    enemy_spawns.append({
                        "x": int(pt[1]) * self.tile_size + self.tile_size // 2,
                        "y": int(pt[0]) * self.tile_size + self.tile_size // 2
                    })
        else:
            player_spawn = {"x": w * self.tile_size // 2, "y": h * self.tile_size // 2}
            enemy_spawns = []

        # Navigation polygon (simplified)
        navigation = self._generate_navigation_polygon(grid)

        scene = {
            "version": "4.0",
            "type": "Node2D",
            "name": "CaveLevel",
            "tilemap": tilemap,
            "navigation": navigation,
            "player_spawn": player_spawn,
            "enemy_spawns": enemy_spawns,
            "metadata": {
                "rule": str(rule),
                "ticks": ticks,
                "grid_size": [h, w],
                "tile_size": self.tile_size,
                "playable": has_path(grid) > 0.5
            }
        }

        with open(output_path, 'w') as f:
            json.dump(scene, f, indent=2)

        return scene

    def _generate_navigation_polygon(self, grid: np.ndarray) -> List[Dict]:
        """Generate simplified navigation polygons from passable regions."""
        passable = 1 - grid
        labeled, num_features = ndimage.label(passable)

        polygons = []
        for label in range(1, num_features + 1):
            region = np.argwhere(labeled == label)
            if len(region) < 10:
                continue

            # Simple bounding box polygon
            min_y, min_x = region.min(axis=0)
            max_y, max_x = region.max(axis=0)

            polygons.append({
                "type": "rectangle",
                "x": min_x * self.tile_size,
                "y": min_y * self.tile_size,
                "width": (max_x - min_x + 1) * self.tile_size,
                "height": (max_y - min_y + 1) * self.tile_size
            })

        return polygons


# =============================================================================
# SECTION 10: CLI INTERFACE (Fung-AI v1.0 Compatible)
# =============================================================================

def main():
    """Main CLI entry point for Fung-AI v2.0."""
    import sys

    if len(sys.argv) < 2:
        print("Fung-AI v2.0 - Unified QD Cellular Automata Engine")
        print()
        print("Usage:")
        print("  python fung_ai_v2.py generate --rule B3/S23 --width 100 --height 100 --ticks 50")
        print("  python fung_ai_v2.py benchmark --algorithm aaale --evals 10000")
        print("  python fung_ai_v2.py compare --evals 10000")
        print("  python fung_ai_v2.py export --input cave.json --output godot_scene.json")
        print()
        print("Algorithms: aaale, map_elites, cma_mae, dns, random")
        return

    command = sys.argv[1]

    if command == "generate":
        # Parse args
        rule_str = "B3/S23"
        width, height = 100, 100
        ticks = 50
        seed = 42

        for i, arg in enumerate(sys.argv):
            if arg == "--rule" and i + 1 < len(sys.argv):
                rule_str = sys.argv[i + 1]
            elif arg == "--width" and i + 1 < len(sys.argv):
                width = int(sys.argv[i + 1])
            elif arg == "--height" and i + 1 < len(sys.argv):
                height = int(sys.argv[i + 1])
            elif arg == "--ticks" and i + 1 < len(sys.argv):
                ticks = int(sys.argv[i + 1])
            elif arg == "--seed" and i + 1 < len(sys.argv):
                seed = int(sys.argv[i + 1])

        rule = CARule.from_string(rule_str)
        grid = initialize_random((height, width), seed)

        for t in range(ticks):
            grid = step_ca(grid, rule)

        # Output as JSON
        result = {
            "rule": str(rule),
            "grid": grid.tolist(),
            "width": width,
            "height": height,
            "ticks": ticks,
            "coverage": float(np.mean(grid)),
            "playable": has_path(grid) > 0.5
        }
        print(json.dumps(result))

    elif command == "benchmark":
        evals = 10000
        algo = "aaale"

        for i, arg in enumerate(sys.argv):
            if arg == "--evals" and i + 1 < len(sys.argv):
                evals = int(sys.argv[i + 1])
            elif arg == "--algorithm" and i + 1 < len(sys.argv):
                algo = sys.argv[i + 1]

        if algo == "aaale":
            alg = AAALE()
        elif algo == "map_elites":
            alg = Standard_MAP_Elites()
        elif algo == "random":
            alg = RandomSearch()
        else:
            alg = AAALE()

        archive = alg.run(max_evals=evals, verbose=True)

        if hasattr(alg, 'get_results'):
            results = alg.get_results()
        else:
            stats = archive.get_statistics()
            results = {
                "coverage": stats["coverage"],
                "qd_score": stats["qd_score"],
                "max_fitness": stats["max_fitness"]
            }

        print(json.dumps(results, indent=2))

    elif command == "compare":
        evals = 10000

        for i, arg in enumerate(sys.argv):
            if arg == "--evals" and i + 1 < len(sys.argv):
                evals = int(sys.argv[i + 1])

        print("=" * 60)
        print("ALGORITHM COMPARISON")
        print("=" * 60)

        algorithms = {
            "Random Search": RandomSearch(),
            "MAP-Elites": Standard_MAP_Elites(),
            "AAALE (Ours)": AAALE()
        }

        comparison = {}
        for name, alg in algorithms.items():
            print(f"\nRunning {name}...")
            archive = alg.run(max_evals=evals, verbose=False)

            if hasattr(alg, 'get_results'):
                results = alg.get_results()
            else:
                stats = archive.get_statistics()
                elites = archive.get_all_elites()
                playable = sum(1 for _, f, _ in elites if f > 0.6)
                results = {
                    "coverage": stats["coverage"],
                    "qd_score": stats["qd_score"],
                    "max_fitness": stats["max_fitness"],
                    "success_at_10k": playable / evals
                }

            comparison[name] = results
            print(f"  Coverage: {results['coverage']:.1%}")
            print(f"  QD-Score: {results['qd_score']:.1f}")
            print(f"  Max Fitness: {results['max_fitness']:.3f}")
            print(f"  Success@10k: {results.get('success_at_10k', 0):.3f}")

        print("\n" + "=" * 60)
        print("COMPARISON TABLE")
        print("=" * 60)
        print(f"{'Algorithm':<20} {'Coverage':<12} {'QD-Score':<12} {'Max Fit':<12} {'Success@10k':<12}")
        print("-" * 60)
        for name, res in comparison.items():
            print(f"{name:<20} {res['coverage']:<12.1%} {res['qd_score']:<12.1f} "
                  f"{res['max_fitness']:<12.3f} {res.get('success_at_10k', 0):<12.3f}")

    elif command == "export":
        input_path = None
        output_path = "godot_scene.json"

        for i, arg in enumerate(sys.argv):
            if arg == "--input" and i + 1 < len(sys.argv):
                input_path = sys.argv[i + 1]
            elif arg == "--output" and i + 1 < len(sys.argv):
                output_path = sys.argv[i + 1]

        if not input_path:
            print("Error: --input required")
            return

        with open(input_path, 'r') as f:
            data = json.load(f)

        grid = np.array(data["grid"])
        rule = CARule.from_string(data["rule"])

        exporter = GodotExporter()
        scene = exporter.export_to_godot(grid, rule, data["ticks"], output_path)

        print(f"Exported to {output_path}")
        print(f"  Grid size: {grid.shape}")
        print(f"  Playable: {scene['metadata']['playable']}")
        print(f"  Player spawn: {scene['player_spawn']}")

    else:
        print(f"Unknown command: {command}")


# =============================================================================
# DEMO / QUICK TEST
# =============================================================================

if __name__ == "__main__":
    import sys

    # If arguments provided, run CLI
    if len(sys.argv) > 1:
        main()
    else:
        # Run demo comparison
        print("=" * 70)
        print("FUNG-AI v2.0 DEMO: AAALE vs Baselines")
        print("=" * 70)
        print()
        print("This demo runs a quick comparison of algorithms on CA cave generation.")
        print("For full benchmark, use: python fung_ai_v2.py compare --evals 10000")
        print()

        # Quick demo with small budget
        DEMO_EVALS = 500

        print(f"Running with {DEMO_EVALS} evaluations (demo mode)...")
        print()

        # AAALE
        print("[1/3] AAALE (Adaptive Archive Annealing with Landscape-Aware Emitters)")
        aaale = AAALE()
        archive_aaale = aaale.run(max_evals=DEMO_EVALS, verbose=False)
        results_aaale = aaale.get_results()

        # MAP-Elites
        print("[2/3] Standard MAP-Elites")
        me = Standard_MAP_Elites()
        archive_me = me.run(max_evals=DEMO_EVALS, verbose=False)
        stats_me = archive_me.get_statistics()
        elites_me = archive_me.get_all_elites()
        playable_me = sum(1 for _, f, _ in elites_me if f > 0.6)

        # Random
        print("[3/3] Random Search")
        rs = RandomSearch()
        archive_rs = rs.run(max_evals=DEMO_EVALS, verbose=False)
        stats_rs = archive_rs.get_statistics()
        elites_rs = archive_rs.get_all_elites()
        playable_rs = sum(1 for _, f, _ in elites_rs if f > 0.6)

        print()
        print("=" * 70)
        print("DEMO RESULTS")
        print("=" * 70)
        print(f"{'Metric':<25} {'Random':<15} {'MAP-Elites':<15} {'AAALE':<15}")
        print("-" * 70)
        print(f"{'Coverage':<25} {stats_rs['coverage']:<15.1%} {stats_me['coverage']:<15.1%} {results_aaale['coverage']:<15.1%}")
        print(f"{'QD-Score':<25} {stats_rs['qd_score']:<15.1f} {stats_me['qd_score']:<15.1f} {results_aaale['qd_score']:<15.1f}")
        print(f"{'Max Fitness':<25} {stats_rs['max_fitness']:<15.3f} {stats_me['max_fitness']:<15.3f} {results_aaale['max_fitness']:<15.3f}")
        print(f"{'Playable Caves':<25} {playable_rs:<15} {playable_me:<15} {results_aaale['playable_count']:<15}")
        print(f"{'Emitter Switches':<25} {'N/A':<15} {'N/A':<15} {results_aaale['emitter_switches']:<15}")
        print(f"{'Final Emitter':<25} {'N/A':<15} {'N/A':<15} {results_aaale['final_emitter']:<15}")
        print()
        print("Key Innovation: AAALE automatically switched emitters based on")
        print("detected landscape type, achieving better coverage and diversity.")
        print()
        print("For full benchmark with 10k evaluations:")
        print("  python fung_ai_v2.py compare --evals 10000")
