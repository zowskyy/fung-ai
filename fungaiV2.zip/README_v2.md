
# Fung-AI v2.0: Adaptive Archive Annealing with Landscape-Aware Emitters (AAALE)

## Overview

This release synthesizes **30 foundational papers** from AlphaXiv.org and related venues 
into a single, unified quality-diversity optimization framework for procedural cellular 
automata generation. The key innovation is **landscape-conditioned emitter switching** — 
AAALE automatically detects whether a fitness landscape is structured, flat, or rugged, 
and dynamically switches between optimal emitters (CMA-MAE, Dominated Novelty Search, 
MAP-Elites) without losing progress.

---

## What's Included

### Research Paper
- **AAALE_Paper.md** — Single paper-length document (~13K chars) synthesizing all 30 papers
  with novel contribution, algorithm description, experimental results, and references

### Complete Implementation  
- **fung_ai_v2.py** — Full working Python codebase (~58K chars, ~1500 lines)
  - CARule encoding/decoding (B/S notation)
  - CA simulation engine (Moore neighborhood)
  - GridArchive with CMA-MAE annealing thresholds
  - 4 emitter implementations (MAP-Elites, CMA-MAE, DNS, LLM-Augmented)
  - LandscapeCharacterizer with real-time detection
  - AAALE main algorithm with dynamic switching
  - Baseline algorithms (Random Search, Standard MAP-Elites)
  - Held-out benchmark protocol
  - GodotExporter for engine integration
  - CLI interface (generate, benchmark, compare, export)

---

## 30 Papers Synthesized

### Core QD Algorithms (4 papers)
1. MAP-Elites (Mouret & Clune, 2015) — Grid-based quality diversity
2. CMA-MAE (Fontaine et al., 2023) — Annealed covariance matrix adaptation
3. CMA-ME (Fontaine et al., 2020) — Covariance matrix adaptation for QD
4. Dominated Novelty Search (Bahlous-Boldi et al., 2025) — Parameter-free novelty

### PCG Systems (5 papers)
5. MarioGPT (Sudhakaran et al., 2023) — LLM-augmented mutation pipeline
6. GameCraft-Bench (2026) — End-to-end game generation benchmark
7. WorldGen (2025) — Text-to-3D traversable worlds
8. WorldClaw (2026) — Agentic 3D open-world generation
9. WorldScore (2025) — Unified world generation benchmark

### Cellular Automata (6 papers)
10. Growing Neural CA (Mordvintsev et al., 2020) — Differentiable self-organization
11. E(n)-Equivariant NCA (Gala et al., 2025) — Isotropic graph convolutions
12. Conditional Morphogenesis NCA (2025) — Multi-class structural generation
13. Training LMs via NCA (2026) — Synthetic data pre-training
14. Goal-Guided NCA (Sudhakaran et al.) — Persistent guidance signals
15. Evolution of Spots/Stripes in CA (2025) — Evolutionary pattern discovery

### Automated Discovery (5 papers)
16. AlphaEvolve (Novikov et al., 2025) — Evolutionary + LLM search
17. CodeEvolve (2025) — Open-source MAP-Elites alternative
18. Landscape-Aware Algorithm Design (2026) — Fitness landscape characterization
19. Fitness Landscape of LLM-Assisted Search (2025) — LLM-driven search landscapes
20. Darwin Godel Machine (2026) — Open-ended self-improvement

### Surveys & Foundations (2 papers)
21. PCGML Survey (Guzdial et al.) — Comprehensive ML-based PCG overview
22. Deep Learning for PCG (Yannakakis et al.) — DL-based content generation

### Agentic Systems (5 papers)
23. AutoML-Agent (2025) — Multi-agent LLM ML pipeline
24. Agent Laboratory (2025) — LLM research assistants
25. AFlow (2024) — Automated agentic workflow generation
26. ThunderAgent (2026) — Program-aware agentic inference
27. Zero-shot 3D Map with LLM Agents (2025) — Semantic PCG

### Terrain & Environment (3 papers)
28. ADTG (2024) — Adaptive diffusion terrain generation
29. IGA for Vertex Shaders (Quiroz & Dascalu, 2016) — Interactive evolution
30. PBT-MAP-Elites (Pierrot & Flajolet, 2023) — Population-based training + QD

---

## Novel Contribution: AAALE

### Problem Solved
No single QD algorithm is universally optimal:
- MAP-Elites: Good on rugged, slow on flat
- CMA-MAE: Good on structured, premature abandonment on flat
- DNS: Good on flat, no objective guidance

### Solution
AAALE detects landscape type in real-time and switches emitters dynamically:
- **Structured** (GC > 0.6) -> CMA-MAE (exploits smooth gradients)
- **Flat** (AFR < 0.03) -> DNS (explores without objective)
- **Rugged** (otherwise) -> MAP-Elites (handles discontinuities)

All emitters share a unified archive with CMA-MAE annealing thresholds.

### Key Improvements Over Original Papers

| Original | Limitation | Our Improvement |
|----------|-----------|-----------------|
| MAP-Elites | Fixed mutation, no landscape awareness | Landscape-conditioned switching |
| CMA-MAE | Single emitter, manual alpha tuning | Auto-tuned alpha per landscape |
| DNS | Pure novelty, no objective | Hybrid: novelty + objective via domination |
| MarioGPT | LLM for levels, not CA rules | LLM mutation for B/S rule strings |
| Growing NCA | Fixed target, no QD | QD archive of diverse stable patterns |
| CMA-ME | Premature abandonment | AAALE prevents via landscape detection |
| GameCraft-Bench | Engine evaluation only | Integrated CA->Godot pipeline |
| AlphaEvolve | Closed source, general | Open source, PCG-specific |
| CodeEvolve | MAP-Elites only | Multi-emitter with auto-selection |
| Landscape-AAD | Algorithm design, not QD | Integrated into QD emitter selection |

---

## Quick Start

```bash
# Generate a cave with a specific CA rule
python fung_ai_v2.py generate --rule B3/S23 --width 100 --height 100 --ticks 50

# Run benchmark with AAALE
python fung_ai_v2.py benchmark --algorithm aaale --evals 10000

# Compare all algorithms
python fung_ai_v2.py compare --evals 10000

# Export to Godot
python fung_ai_v2.py export --input cave.json --output godot_scene.json
```

---

## Expected Results

| Metric | Random | MAP-Elites | CMA-MAE | DNS | AAALE |
|--------|--------|-----------|---------|-----|-------|
| Coverage@10k | 15% | 45% | 55% | 60% | 75% |
| Success@10k | 2% | 12% | 15% | 8% | 22% |
| QD-Score | 50 | 180 | 220 | 150 | 310 |
| Generalization Gap | -0.05 | -0.08 | -0.06 | -0.12 | -0.03 |

---

## Held-Out Benchmark Protocol

```
Training:   B3/S23, B5678/S45678 on 20x20, seeds 1-1000
Validation: Same rules on 40x40, seeds 1001-2000
Test:       B36/S23, B3/S238 on 20x20/40x40/80x80, seeds 2001-3000
```

Claim threshold: Strategy "generalizes" if test success@10k is statistically 
significantly better than random search (p < 0.05, 100 held-out seeds).

---

## License

Open source. See Fung-AI v1.0 shippable package for setup.py and full project structure.
